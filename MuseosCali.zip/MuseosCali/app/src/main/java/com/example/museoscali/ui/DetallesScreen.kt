package com.example.museoscali.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import com.example.museoscali.viewmodel.Museo
import com.example.museoscali.R

@Composable
fun DetallesScreen(
    backgroundColor: MutableState<Color>,
    textColor: Color,
    surfaceColor: Color,
    onMuseoClick: (Museo) -> Unit,
    historial: List<Museo>,
    favoritos: List<Museo>
) {
    val museos = remember {
        listOf(
            Museo("Museo La Tertulia", "Museo de arte moderno y contemporáneo en Cali.", "Av. Colombia #5-105, Cali", R.drawable.tertulia),
            Museo("Museo Calima", "Muestra la historia prehispánica del suroccidente colombiano.", "Carrera 10 #8-83, Cali", R.drawable.calima),
            Museo("Museo Rayo", "Fundado por Omar Rayo, especializado en arte geométrico y gráfico.", "Roldanillo, Valle del Cauca", R.drawable.rayo),
            Museo("Museo del Oro Calima", "Exhibe objetos de oro, cerámica y piedra de culturas prehispánicas.", "Carrera 10 #8-83, Centro Histórico", R.drawable.oro_calima),
            Museo("Museo Arqueológico La Merced", "Colecciones de cerámica indígena y elementos coloniales.", "Cra. 4 #6-59, Cali", R.drawable.la_merced),
            Museo("Museo de Arte Religioso", "Exhibe piezas de arte sacro y objetos religiosos.", "Calle 6 #6-72, Centro Histórico, Cali", R.drawable.arte_religioso)
        )
    }

    var searchQuery by remember { mutableStateOf(TextFieldValue("")) }
    var filtro by remember { mutableStateOf("explorar") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor.value)
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Buscar museos", color = textColor) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = textColor,
                unfocusedTextColor = textColor
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Favoritos", "Historial", "Explorar").forEach { label ->
                AssistChip(
                    onClick = { filtro = label.lowercase() },
                    label = { Text(label, color = textColor) },
                    shape = RoundedCornerShape(50),
                    colors = AssistChipDefaults.assistChipColors(containerColor = surfaceColor)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val resultados = when (filtro) {
            "historial" -> historial
            "favoritos" -> favoritos
            else -> museos.filter {
                it.nombre.contains(searchQuery.text, ignoreCase = true)
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(resultados) { museo ->
                val esFavorito = favoritos.contains(museo)
                MuseoCard(museo = museo, esFavorito = esFavorito, onClick = { onMuseoClick(museo) }, textColor = textColor, surfaceColor = surfaceColor)
            }
        }
    }
}

@Composable
fun MuseoCard(museo: Museo, esFavorito: Boolean, onClick: () -> Unit, textColor: Color, surfaceColor: Color) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = surfaceColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp)) {
            Image(
                painter = painterResource(museo.imagenRes),
                contentDescription = museo.nombre,
                modifier = Modifier
                    .size(80.dp)
                    .aspectRatio(1f)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = museo.nombre,
                    style = MaterialTheme.typography.titleMedium,
                    color = textColor
                )
                Text(
                    text = museo.descripcion,
                    style = MaterialTheme.typography.bodySmall,
                    color = textColor.copy(alpha = 0.7f)
                )
            }
            if (esFavorito) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "Favorito",
                    tint = Color(0xFFFFC107),
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
