package com.example.museoscali.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun ConfiguracionScreen(
    backgroundColor: MutableState<Color>,
    onColorChange: (Color) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor.value)
            .padding(16.dp)
    ) {
        Text("Selecciona un color de fondo", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                val newColor = Color(0xFFFFF176) // Amarillo claro
                backgroundColor.value = newColor
                onColorChange(newColor)
            }) {
                Text("Amarillo")
            }

            Button(onClick = {
                val newColor = Color(0xFF80DEEA) // Cian claro
                backgroundColor.value = newColor
                onColorChange(newColor)
            }) {
                Text("Cian")
            }

            Button(onClick = {
                val newColor = Color.White
                backgroundColor.value = newColor
                onColorChange(newColor)
            }) {
                Text("Blanco")
            }
        }
    }
}

