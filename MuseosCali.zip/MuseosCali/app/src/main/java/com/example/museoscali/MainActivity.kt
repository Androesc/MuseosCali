package com.example.museoscali

import android.os.Bundle
import android.content.Context
import com.example.museoscali.R
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.museoscali.ui.DetallesScreen
import com.example.museoscali.ui.ConfiguracionScreen
import com.example.museoscali.ui.MuseoDetalleScreen
import com.example.museoscali.viewmodel.Museo
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import android.view.LayoutInflater
import android.widget.Button
import com.example.museoscali.ui.theme.MuseosCaliTheme
import androidx.compose.ui.viewinterop.AndroidView
import android.graphics.Color as AndroidColor

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MuseosCaliTheme {
                MuseoApp()
            }
        }
    }
}

@Composable
fun MuseoApp() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    val defaultColor = prefs.getInt("background_color", Color.White.toArgb())
    val backgroundColor = remember { mutableStateOf(Color(defaultColor)) }
    val isDarkMode = remember { mutableStateOf(defaultColor == Color.Black.toArgb()) }
    val museoSeleccionado = remember { mutableStateOf<Museo?>(null) }
    val historial = remember { mutableStateListOf<Museo>() }
    val favoritos = remember { mutableStateListOf<Museo>() }

    val textColor = if (isDarkMode.value) Color.White else Color.Black
    val surfaceColor = if (isDarkMode.value) Color(0xFF2C2C2C) else Color(0xFFE0E0E0)

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate("configuracion") }) {
                Icon(Icons.Default.Settings, contentDescription = "Configuración")
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            NavHost(navController, startDestination = "inicio") {
                composable("inicio") {
                    AndroidView(
                        factory = { context ->
                            val view = LayoutInflater.from(context).inflate(R.layout.activity_inicio, null)

                            view.setBackgroundColor(backgroundColor.value.toArgb())

                            val titulo = view.findViewById<TextView>(R.id.titulo)
                            val subtitulo = view.findViewById<TextView>(R.id.subtitulo)
                            val textoInstruccion = view.findViewById<TextView>(R.id.textoInstruccion)
                            val terminos = view.findViewById<TextView>(R.id.terminos)
                            val emailInput = view.findViewById<EditText>(R.id.emailInput)
                            val continuarBtn = view.findViewById<Button>(R.id.btnContinuar)

                            titulo.setTextColor(textColor.toArgb())
                            subtitulo.setTextColor(textColor.toArgb())
                            textoInstruccion.setTextColor(textColor.toArgb())
                            terminos.setTextColor(textColor.copy(alpha = 0.7f).toArgb())

                            emailInput.setTextColor(if (isDarkMode.value) AndroidColor.BLACK else AndroidColor.BLACK)
                            emailInput.setHintTextColor(AndroidColor.DKGRAY)

                            continuarBtn.setBackgroundColor(
                                if (isDarkMode.value) AndroidColor.WHITE else AndroidColor.BLACK
                            )
                            continuarBtn.setTextColor(
                                if (isDarkMode.value) AndroidColor.BLACK else AndroidColor.WHITE
                            )

                            continuarBtn.setOnClickListener {
                                val email = emailInput.text.toString().trim()
                                if (email == "demo@cali.com") {
                                    navController.navigate("detalles")
                                } else {
                                    Toast.makeText(context, "Correo inválido", Toast.LENGTH_SHORT).show()
                                }
                            }

                            view
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                composable("detalles") {
                    DetallesScreen(
                        backgroundColor = backgroundColor,
                        textColor = textColor,
                        surfaceColor = surfaceColor,
                        onMuseoClick = { museo ->
                            if (!historial.contains(museo)) {
                                historial.add(museo)
                            }
                            museoSeleccionado.value = museo
                            navController.navigate("museo_detalle")
                        },
                        historial = historial,
                        favoritos = favoritos
                    )
                }
                composable("museo_detalle") {
                    museoSeleccionado.value?.let { museo ->
                        MuseoDetalleScreen(
                            museo = museo,
                            onFavoritoClick = {
                                if (!favoritos.contains(museo)) {
                                    favoritos.add(museo)
                                    Toast.makeText(context, "${museo.nombre} añadido a favoritos", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "${museo.nombre} ya está en favoritos", Toast.LENGTH_SHORT).show()
                                }
                            },
                            backgroundColor = backgroundColor.value,
                            textColor = textColor,
                            surfaceColor = surfaceColor
                        )
                    }
                }
                composable("configuracion") {
                    Surface(color = backgroundColor.value, modifier = Modifier.fillMaxSize()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Modo oscuro", style = MaterialTheme.typography.titleMedium, color = textColor)
                            Switch(
                                checked = isDarkMode.value,
                                onCheckedChange = { checked ->
                                    isDarkMode.value = checked
                                    val newColor = if (checked) Color.Black else Color.White
                                    backgroundColor.value = newColor
                                    prefs.edit().putInt("background_color", newColor.toArgb()).apply()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
