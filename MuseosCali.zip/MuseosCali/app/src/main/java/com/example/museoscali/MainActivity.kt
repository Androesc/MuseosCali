package com.example.museoscali

import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.compose.*
import com.example.museoscali.ui.*
import com.example.museoscali.ui.theme.MuseosCaliTheme
import com.example.museoscali.viewmodel.Museo
import com.google.android.gms.auth.api.signin.*
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.*
import android.graphics.Color as AndroidColor

class MainActivity : ComponentActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var googleSignInClient: GoogleSignInClient

    private val signInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(ApiException::class.java)
                firebaseAuthWithGoogle(account.idToken!!)
            } catch (e: Exception) {
                Log.w("MainActivity", "Google sign in failed", e)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        auth = FirebaseAuth.getInstance()

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        setContent {
            MuseosCaliTheme {
                MuseoApp(auth, googleSignInClient, signInLauncher)
            }
        }
    }

    private fun firebaseAuthWithGoogle(idToken: String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    Toast.makeText(this, "Bienvenido ${user?.displayName}", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Falló la autenticación", Toast.LENGTH_SHORT).show()
                }
            }
    }
}

@Composable
fun MuseoApp(
    auth: FirebaseAuth,
    googleSignInClient: GoogleSignInClient,
    signInLauncher: ActivityResultLauncher<Intent>
) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("prefs", Context.MODE_PRIVATE)
    val defaultColor = prefs.getInt("background_color", Color.White.toArgb())
    val backgroundColor = remember { mutableStateOf(Color(defaultColor)) }
    val isDarkMode = remember { mutableStateOf(defaultColor == Color.Black.toArgb()) }
    val museoSeleccionado = remember { mutableStateOf<Museo?>(null) }
    val historial = remember { mutableStateListOf<Museo>() }
    val favoritos = remember { mutableStateListOf<Museo>() }

    val textColor = if (isDarkMode.value) Color.White else Color.Black
    val surfaceColor = if (isDarkMode.value) Color(0xFF2C2C2C) else Color(0xFFE0E0E0)

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { navController.navigate("configuracion") }) {
                Icon(Icons.Default.Settings, contentDescription = "Configuración")
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues)) {
            NavHost(navController, startDestination = "inicio") {
                composable("inicio") {
                    AndroidView(
                        factory = { context ->
                            val view = LayoutInflater.from(context).inflate(R.layout.activity_inicio, null)

                            view.setBackgroundColor(backgroundColor.value.toArgb())

                            val titulo = view.findViewById<TextView>(R.id.titulo)
                            val subtitulo = view.findViewById<TextView>(R.id.subtitulo)
                            val textoInstruccion = view.findViewById<TextView>(R.id.textoInstruccion)
                            val terminos = view.findViewById<TextView>(R.id.terminos)
                            val emailInput = view.findViewById<EditText>(R.id.emailInput)
                            val passwordInput = view.findViewById<EditText>(R.id.passwordInput)
                            val continuarBtn = view.findViewById<Button>(R.id.btnContinuar)
                            val signInButton = view.findViewById<SignInButton>(R.id.sign_in_button)

                            titulo.setTextColor(textColor.toArgb())
                            subtitulo.setTextColor(textColor.toArgb())
                            textoInstruccion.setTextColor(textColor.toArgb())
                            terminos.setTextColor(textColor.copy(alpha = 0.7f).toArgb())

                            emailInput.setTextColor(if (isDarkMode.value) AndroidColor.WHITE else AndroidColor.BLACK)
                            emailInput.setHintTextColor(AndroidColor.DKGRAY)
                            passwordInput.setTextColor(if (isDarkMode.value) AndroidColor.WHITE else AndroidColor.BLACK)
                            passwordInput.setHintTextColor(AndroidColor.DKGRAY)

                            continuarBtn.setBackgroundColor(
                                if (isDarkMode.value) AndroidColor.WHITE else AndroidColor.BLACK
                            )
                            continuarBtn.setTextColor(
                                if (isDarkMode.value) AndroidColor.BLACK else AndroidColor.WHITE
                            )

                            continuarBtn.setOnClickListener {
                                val email = emailInput.text.toString().trim()
                                val password = passwordInput.text.toString().trim()

                                if (email.equals("demo@cali.com", ignoreCase = true)) {
                                    navController.navigate("detalles")
                                } else if (email.isNotEmpty() && password.isNotEmpty()) {
                                    auth.signInWithEmailAndPassword(email, password)
                                        .addOnCompleteListener { task ->
                                            if (task.isSuccessful) {
                                                navController.navigate("detalles")
                                            } else {
                                                Toast.makeText(context, "Correo o contraseña inválidos", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                } else {
                                    Toast.makeText(context, "Completa los campos", Toast.LENGTH_SHORT).show()
                                }
                            }

                            signInButton.setOnClickListener {
                                signInLauncher.launch(googleSignInClient.signInIntent)
                            }

                            view
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                composable("detalles") {
                    DetallesScreen(
                        backgroundColor = backgroundColor,
                        textColor = textColor,
                        surfaceColor = surfaceColor,
                        onMuseoClick = { museo ->
                            if (!historial.contains(museo)) {
                                historial.add(museo)
                            }
                            museoSeleccionado.value = museo
                            navController.navigate("museo_detalle")
                        },
                        historial = historial,
                        favoritos = favoritos,
                        onAbrirMapaClick = {
                            navController.navigate("mapa") // ✅ Nueva navegación al mapa
                        }
                    )
                }

                composable("museo_detalle") {
                    museoSeleccionado.value?.let { museo ->
                        MuseoDetalleScreen(
                            museo = museo,
                            onFavoritoClick = {
                                if (!favoritos.contains(museo)) {
                                    favoritos.add(museo)
                                    Toast.makeText(context, "${museo.nombre} añadido a favoritos", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "${museo.nombre} ya está en favoritos", Toast.LENGTH_SHORT).show()
                                }
                            },
                            backgroundColor = backgroundColor.value,
                            textColor = textColor,
                            surfaceColor = surfaceColor
                        )
                    }
                }

                composable("configuracion") {
                    Surface(color = backgroundColor.value, modifier = Modifier.fillMaxSize()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Modo oscuro", style = MaterialTheme.typography.titleMedium, color = textColor)
                            Switch(
                                checked = isDarkMode.value,
                                onCheckedChange = { checked ->
                                    isDarkMode.value = checked
                                    val newColor = if (checked) Color.Black else Color.White
                                    backgroundColor.value = newColor
                                    prefs.edit().putInt("background_color", newColor.toArgb()).apply()
                                }
                            )
                        }
                    }
                }

                composable("mapa") {
                    OpenStreetMapScreen(context = context)
                }
            }
        }
    }
}
