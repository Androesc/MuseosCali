package com.example.museoscali.viewmodel

import androidx.annotation.DrawableRes
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.museoscali.R

data class Museo(
    val nombre: String,
    val descripcion: String,
    val direccion: String,
    @DrawableRes val imagenRes: Int
)

class DetallesViewModel : ViewModel() {

    private val _museoData = MutableLiveData<Museo>().apply {
        value = Museo(
            nombre = "Museo La Tertulia",
            descripcion = "Uno de los principales museos de arte moderno y contemporáneo en Cali.",
            direccion = "Av. Colombia #5-105, Cali",
            imagenRes = R.drawable.tertulia
        )
    }

    val museoData: LiveData<Museo> = _museoData
}
